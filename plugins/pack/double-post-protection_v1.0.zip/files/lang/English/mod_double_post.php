﻿<?php

// Language definitions used by the double post protection mod
$lang_mod_double_post = array(

'Double post label'		=> 'Double-post interval',
'Double post help'		=> 'Number of minutes that users in this group have to wait between two consecutive posts in the same topic. Set to 0 to disable.',
'Double post start'		=> 'At least',
'Double post end'		=> 'minutes have to pass between  two consecutive posts in the same topic. Please wait a little while or edit your precedent post.'

);