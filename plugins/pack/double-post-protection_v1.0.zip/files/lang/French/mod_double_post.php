﻿<?php

// Language definitions used by the double post protection mod
$lang_mod_double_post = array(

'Double post label'		=> 'Intervalle de double-post',
'Double post help'		=> 'Délai en minutes à respecter par les utilisateurs de ce groupe entre deux messages postés l\'un à la suite de l\'autre dans la même discussion. Définir à 0 pour désactiver.',
'Double post start'		=> 'Au moins',
'Double post end'		=> 'minutes doivent s\'écouler entre deux messages consécutifs dans la même discussion. Veuillez patientez ou modifiez votre message précédent.'

);