<?php
/***********************************************************************

  PascL (kokoala2k3@free.fr)

************************************************************************/

// Make sure no one attempts to run this script "directly"
if (!defined('PUN'))
	exit;

// Tell admin_loader.php that this is indeed a plugin and that it is loaded
define('PUN_PLUGIN_LOADED', 1);

define('PLUGIN_URL', 'admin_loader.php?plugin=AMP_Sondage.php');

require PUN_ROOT . 'lang/' . $pun_user['language'] . '/polls.php';

$now=time();

if (isset($_GET['edit']))
{
	// marqueur si ya erreur
	$found_error=false;
	// init pour se passer d'une condition lors de la requ�te update
	$noval='';
	$yesval='';
	
	// si on a modifi�
	if((isset($_POST['add_edit']))&&(isset($_POST['poll_id'])))
	{
		$id=intval($_POST['poll_id']);
		$ptype=intval($_POST['ptype']);
		if(($ptype<1)||($ptype>3))
			message('Sondage de type inconnu.');
		
		confirm_referrer(PLUGIN_URL.'&edit='.$id);
		
		
		$question = pun_trim($_POST['req_question']);
        if ($question == '')
            $errors[] = $lang_polls['No question'];
        else if (pun_strlen($question) > 70)
            $errors[] = $lang_polls['Too long question'];
        else if ($pun_config['p_subject_all_caps'] == '0' && strtoupper($question) == $question && ($pun_user['g_id'] > PUN_MOD && !$pun_user['g_global_moderation']))
            $question = ucwords(strtolower($question)); 
        // If its a multislect yes/no poll then we need to make sure they have the right values
        if ($ptype == 3) 
		{
            $yesval = pun_trim($_POST['poll_yes']);

            if ($yesval == '')
                $errors[] = $lang_polls['No yes'];
            else if (pun_strlen($yesval) > 35)
                $errors[] = $lang_polls['Too long yes'];
            else if ($pun_config['p_subject_all_caps'] == '0' && strtoupper($yesval) == $yesval && ($pun_user['g_id'] > PUN_MOD && !$pun_user['g_global_moderation']))
                $yesval = ucwords(strtolower($yesval));

            $noval = pun_trim($_POST['poll_no']);

            if ($noval == '')
                $errors[] = $lang_polls['No no'];
            else if (pun_strlen($noval) > 35)
                $errors[] = $lang_polls['Too long no'];
            else if ($pun_config['p_subject_all_caps'] == '0' && strtoupper($noval) == $noval && ($pun_user['g_id'] > PUN_MOD && !$pun_user['g_global_moderation']))
                $noval = ucwords(strtolower($noval));
        } 
        // This isn't exactly a good way todo it, but it works. I may rethink this code later
        $option = array();
        $lastoption = "null";
        while (list($key, $value) = each($_POST['poll_option'])) 
		{
			$value = pun_trim($value);
            if ($value != "") 
			{
                if ($lastoption == '')
                    $errors[] = $lang_polls['Empty option'];

                $option[$key] = pun_trim($value);
                if (pun_strlen($option[$key]) > 55)
                    $errors[] = $lang_polls['Too long option'];
				else if ($key > $pun_config['poll_max_fields'])
					message($lang_common['Bad request']);
                else if ($pun_config['p_subject_all_caps'] == '0' && strtoupper($option[$key]) == $option[$key] && ($pun_user['g_id'] > PUN_MOD && !$pun_user['g_global_moderation']))
                    $option[$key] = ucwords(strtolower($option[$key]));
            } 
            $lastoption = pun_trim($value);
        } 

		// People are naughty
		if (empty($option))
			$errors[] = $lang_polls['No options'];

		if (!array_key_exists(2,$option))
			$errors[] = $lang_polls['Low options'];

		
		// If there are errors, we display them
	    if (!empty($errors)) 
		{
			$found_error=true;
			$cur_index=1;
		?>
		<div id="posterror" class="block">
				<h2><span><?php echo $lang_post['Post errors'] ?></span></h2>
				<div class="box">
					<div class="inbox">
						<p><?php echo $lang_post['Post errors info'] ?></p>
						<ul>
						<?php
				        while (list(, $cur_error) = each($errors))
				        echo "\t\t\t\t" . '<li><strong>' . $cur_error . '</strong></li>' . "\n";
						?>
						</ul>
					</div>
				</div>
		</div>
		<?php
		}
		else
		{
			$db->query('UPDATE ' . $db->prefix . 'topics SET question=\'' . $db->escape($question) . '\', yes=\'' . $db->escape($yesval) . '\', no=\'' . $db->escape($noval) . '\' WHERE id='.$id) or error('Unable to update poll in topic table', __FILE__, __LINE__, $db->error());
			$db->query('UPDATE ' . $db->prefix . 'polls SET options=\'' . $db->escape(serialize($option)) . '\', edited='.$now.' WHERE pollid='.$id) or error('Unable to update poll in poll table', __FILE__, __LINE__, $db->error());
			redirect(PLUGIN_URL, 'Sondage mis � jour. Redirection ...');
		}
	}
	
	// si found_error est faux,
	// - soit on vient de cliquer sur modifier
	// - soit on a d�j� modifi�, sans trouver d'erreurs et on est d�j� redirig� par le redirect au-dessus
	if($found_error==false)
	{
		$id = intval($_GET['edit']);
		
		// Requ�te SELECT
		$result = $db->query('SELECT t.question, t.yes, t.no, p.options, p.ptype, f.moderators FROM '.$db->prefix.'polls AS p INNER JOIN '.$db->prefix.'topics AS t ON p.pollid=t.id INNER JOIN '.$db->prefix.'forums AS f ON t.forum_id=f.id WHERE p.pollid='.$id.' LIMIT 1') or error('Unable to find poll', __FILE__, __LINE__, $db->error());
		if(!$db->num_rows($result))
			message('Cet id sondage n\'existe pas dans la base de donn�es.');

		$cur_poll = $db->fetch_assoc($result);
		
		$poll_editable=false;
		if($pun_user['group_id']!=PUN_ADMIN)
		{
			if ($cur_poll['moderators'] != '')
			{
				$mods_array = unserialize($cur_poll['moderators']);
				$moderators = array();
		
				while (list(, $mod_id) = @each($mods_array))
					$moderators[] = $mod_id;
		
				if(in_array($pun_user['id'],$moderators))
				{
					$poll_editable=true;
				}
			}
		}
		else
		{
			$poll_editable=true;
		}
		
		if(!$poll_editable)
			message('Vous ne pouvez pas �diter ce sondage.');
		
		$ptype=$cur_poll['ptype'];
		$option=unserialize($cur_poll['options']);
		$question=$cur_poll['question'];
		$yesval=$cur_poll['yes'];
		$noval=$cur_poll['no'];
		$cur_index=1;
	}

		// oblig� de copier le javascript du header car le header a d�j� �t� appel� et $required_fields n'�tait pas d�fini		
		$required_fields = array('req_question' => $lang_polls['Question']);
		$focus_element = array('req_question');
		?>
			<script type="text/javascript">
			<!--
			function process_form(the_form)
			{
				var element_names = new Object()
			<?php
			
				// Output a JavaScript array with localised field names
				while (list($elem_orig, $elem_trans) = @each($required_fields))
					echo "\t".'element_names["'.$elem_orig.'"] = "'.addslashes(str_replace('&nbsp;', ' ', $elem_trans)).'"'."\n";
			
			?>
			
				if (document.all || document.getElementById)
				{
					for (i = 0; i < the_form.length; ++i)
					{
						var elem = the_form.elements[i]
						if (elem.name && elem.name.substring(0, 4) == "req_")
						{
							if (elem.type && (elem.type=="text" || elem.type=="textarea" || elem.type=="password" || elem.type=="file") && elem.value=='')
							{
								alert("\"" + element_names[elem.name] + "\" <?php echo $lang_common['required field'] ?>")
								elem.focus()
								return false
							}
						}
					}
				}
			
				return true
			}
			// -->
			</script>
		<?php
		
		// Display the admin navigation menu
		generate_admin_menu($plugin);
		
		?>
		<div class="blockform">
			<h2><span>Edition d'un sondage</span></h2>
			<div class="box">
				<form id="poll_edit" method="post" action="<?php echo PLUGIN_URL.'&amp;edit='.$id; ?>" onsubmit="return process_form(this)">
					<p class="submittop"><input type="submit" name="add_edit" value=" Enregistrer " tabindex="<?php echo $cur_index++ ?>" />
					<input type="hidden" name="poll_id" value="<?php echo $id; ?>" />
					<input type="hidden" name="ptype" value="<?php echo $ptype; ?>" /></p>
					<div class="inform">
						<fieldset>
						<?php			
					    // Regular Poll Type
					    if ($ptype == 1) 
						{
						?>
							<legend><?php echo $lang_polls['New poll legend'] ?></legend>
							<div class="infldset">
									<label><strong><?php echo $lang_polls['Question'] ?></strong><br /><input type="text" name="req_question" value="<?php echo pun_htmlspecialchars($question); ?>" size="80" maxlength="70" tabindex="<?php echo $cur_index++ ?>" /><br /><br /></label>
									<?php
									for ($x = 1; $x <= $pun_config['poll_max_fields'] ;$x++) 
									{
									?>
										<label><strong><?php echo $lang_polls['Option'] ?></strong><br /> <input type="text" name="poll_option[<?php echo $x; ?>]" value="<?php echo pun_htmlspecialchars($option[$x]); ?>" size="60" maxlength="55" tabindex="<?php echo $cur_index++ ?>" /><br /></label>
									<?php
									} 
									?></div></fieldset></div><?php
					    } 
						// Multiselect poll type
						elseif ($ptype == 2) 
						{
						?>
							<legend><?php echo $lang_polls['New poll legend multiselect'] ?></legend>
							<div class="infldset">
								<label><strong><?php echo $lang_polls['Question'] ?></strong><br /><input type="text" name="req_question" value="<?php echo pun_htmlspecialchars($question); ?>" size="80" maxlength="70" tabindex="<?php echo $cur_index++ ?>" /><br /><br /></label>
								<?php
								for ($x = 1; $x <= $pun_config['poll_max_fields']; $x++) 
								{
									?>
									<label><strong><?php echo $lang_polls['Option'] ?></strong><br /> <input type="text" name="poll_option[<?php echo $x; ?>]" value="<?php echo pun_htmlspecialchars($option[$x]); ?>" size="60" maxlength="55" tabindex="<?php echo $cur_index++ ?>" /><br /></label>
									<?php
								} 
								?></div></fieldset></div><?php
						} 
						elseif ($ptype == 3) 
						{
						?>
							<legend><?php echo $lang_polls['New poll legend yesno'] ?></legend>
							<div class="infldset">
								<label><strong><?php echo $lang_polls['Question'] ?></strong><br /><input type="text" name="req_question" value="<?php echo pun_htmlspecialchars($question); ?>" size="80" maxlength="70" tabindex="<?php echo $cur_index++ ?>" /><br /><br /></label>
								<label><strong><?php echo $lang_polls['Yes'] ?></strong><br /> <input type="text" name="poll_yes" value="<?php echo pun_htmlspecialchars($yesval); ?>" size="40" maxlength="35" tabindex="<?php echo $cur_index++ ?>" /></label>
								<label><strong><?php echo $lang_polls['No'] ?></strong><br /> <input type="text" name="poll_no" value="<?php echo pun_htmlspecialchars($noval); ?>" size="40" maxlength="35" tabindex="<?php echo $cur_index++ ?>" /><br /><br /></label>
								<?php
								for ($x = 1; $x <= $pun_config['poll_max_fields']; $x++) 
								{
									?>
									<label><strong><?php echo $lang_polls['Option'] ?></strong><br /> <input type="text" name="poll_option[<?php echo $x; ?>]" value="<?php echo pun_htmlspecialchars($option[$x]); ?>" size="60" maxlength="55" tabindex="<?php echo $cur_index++ ?>" /><br /></label>
									<?php
								} 
								?></div></fieldset></div><?php
						} 
						?>
						<p class="submitend"><input type="submit" name="add_edit" value=" Enregistrer " tabindex="<?php echo $cur_index++ ?>" /></p>
				</form>
			</div>
		</div>
	
		<?php
}
else if (isset($_GET['add']))
{
	
	// marqueur si ya erreur
	$found_error=false;
	$cur_index=1;
	
	// si on a envoy� un nouveau sondage
	if((isset($_POST['add_poll']))&&(isset($_POST['topic_id'])))
	{
		$id=intval($_POST['topic_id']);
		$ptype=intval($_POST['ptype']);
		if(($ptype<1)||($ptype>3))
			message('Sondage de type inconnu.');
		
		confirm_referrer(PLUGIN_URL.'&add='.$id);
		
		
		$question = pun_trim($_POST['req_question']);
        if ($question == '')
            $errors[] = $lang_polls['No question'];
        else if (pun_strlen($question) > 70)
            $errors[] = $lang_polls['Too long question'];
        else if ($pun_config['p_subject_all_caps'] == '0' && strtoupper($question) == $question && ($pun_user['g_id'] > PUN_MOD && !$pun_user['g_global_moderation']))
            $question = ucwords(strtolower($question)); 
        // If its a multislect yes/no poll then we need to make sure they have the right values
        if ($ptype == 3) 
		{
            $yesval = pun_trim($_POST['poll_yes']);

            if ($yesval == '')
                $errors[] = $lang_polls['No yes'];
            else if (pun_strlen($yesval) > 35)
                $errors[] = $lang_polls['Too long yes'];
            else if ($pun_config['p_subject_all_caps'] == '0' && strtoupper($yesval) == $yesval && ($pun_user['g_id'] > PUN_MOD && !$pun_user['g_global_moderation']))
                $yesval = ucwords(strtolower($yesval));

            $noval = pun_trim($_POST['poll_no']);

            if ($noval == '')
                $errors[] = $lang_polls['No no'];
            else if (pun_strlen($noval) > 35)
                $errors[] = $lang_polls['Too long no'];
            else if ($pun_config['p_subject_all_caps'] == '0' && strtoupper($noval) == $noval && ($pun_user['g_id'] > PUN_MOD && !$pun_user['g_global_moderation']))
                $noval = ucwords(strtolower($noval));
        } 
        // This isn't exactly a good way todo it, but it works. I may rethink this code later
        $option = array();
        $lastoption = "null";
        while (list($key, $value) = each($_POST['poll_option'])) 
		{
			$value = pun_trim($value);
            if ($value != "") 
			{
                if ($lastoption == '')
                    $errors[] = $lang_polls['Empty option'];
                    
                $option[$key] = pun_trim($value);
                if (pun_strlen($option[$key]) > 55)
                    $errors[] = $lang_polls['Too long option'];
				else if ($key > $pun_config['poll_max_fields'])
					message($lang_common['Bad request']);
                else if ($pun_config['p_subject_all_caps'] == '0' && strtoupper($option[$key]) == $option[$key] && ($pun_user['g_id'] > PUN_MOD && !$pun_user['g_global_moderation']))
                    $option[$key] = ucwords(strtolower($option[$key]));
            } 
            $lastoption = pun_trim($value);
        } 

		// People are naughty
		if (empty($option))
			$errors[] = $lang_polls['No options'];

		if (!array_key_exists(2,$option))
			$errors[] = $lang_polls['Low options'];

		
		// If there are errors, we display them
	    if (!empty($errors)) 
		{
			$found_error=true;
		?>
		<div id="posterror" class="block">
				<h2><span><?php echo $lang_post['Post errors'] ?></span></h2>
				<div class="box">
					<div class="inbox">
						<p><?php echo $lang_post['Post errors info'] ?></p>
						<ul>
						<?php
				        while (list(, $cur_error) = each($errors))
				        echo "\t\t\t\t" . '<li><strong>' . $cur_error . '</strong></li>' . "\n";
						?>
						</ul>
					</div>
				</div>
		</div>
		<?php
		}
		else
		{
			$db->query('UPDATE '.$db->prefix.'topics SET question=\'' . $db->escape($question) . '\', yes=\'' . $db->escape($yesval) . '\', no=\'' . $db->escape($noval) . '\' WHERE id='.$id) or error('Unable to create poll in topic table', __FILE__, __LINE__, $db->error());
			$db->query('INSERT INTO '.$db->prefix.'polls (options, ptype, pollid, created) VALUES (\'' . $db->escape(serialize($option)) . '\', '.$ptype.', '.$id.', '.$now.')') or error('Unable to create poll in poll table', __FILE__, __LINE__, $db->error());
			redirect(PLUGIN_URL, 'Sondage ajout�. Redirection ...');
		}
	}
	
	// si found_error est faux,
	// - soit on vient d'arriver sur la page de nouveau sondage
	// - soit on vient de choisir le type de sondage
	// - soit on a d�j� envoy� le nouveau sondage, sans trouver d'erreurs et on est d�j� redirig� par le redirect au-dessus
	if($found_error==false)
	{
		$id = intval($_GET['add']);
		if(isset($_POST['ptype']) && isset($_POST['submit']))
		{
			$ptype=intval($_POST['ptype']);
			
			if(($ptype<1)||($ptype>3))
				message('Sondage de type inconnu.');
		}
		else
			$ptype=0;
		
		$result = $db->query('SELECT f.forum_name, f.moderators, c.cat_name, c.id AS cid, fp.post_polls, t.question FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$db->prefix.'categories AS c ON f.cat_id=c.id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id='.$pun_user['g_id'].') WHERE t.id='.$id) or error('Unable to fetch topic info', __FILE__, __LINE__, $db->error());
		
		// si le topic existe pas
		if (!$db->num_rows($result))
			message('Cet id de sujet n\'existe pas dans al base de donn�es.');
		
		$cur_topic = $db->fetch_assoc($result);

		// si c'est d�j� un sondage...
		if($cur_topic['question']!='')
			message('Ce sujet est d�j� li� � un sondage.');
		
		$poll_editable=false;
		if($pun_user['group_id']!=PUN_ADMIN)
		{
			if ($cur_topic['moderators'] != '')
			{
				$mods_array = unserialize($cur_topic['moderators']);
				$moderators = array();
		
				while (list(, $mod_id) = @each($mods_array))
					$moderators[] = $mod_id;
		
				if(in_array($pun_user['id'],$moderators))
				{
					$poll_editable=true;
				}
			}
		}
		else
		{
			$poll_editable=true;
		}
		
		if(!$poll_editable)
			message('Vous ne pouvez pas �diter ce sondage.');
		
		// si on a pas le droit de poster des sondages dans ce forum
		if(!(($cur_topic['post_polls'] == '' && $pun_user['g_post_polls'] == '1') || $cur_topic['post_polls'] == '1'))
			message('Vous n\'avez pas l\'autorisation de poster des sondages dans ce forum.');
			
		if ($ptype == 0) 
		{
		    $form = '<form id="post" method="post" action="'.PLUGIN_URL.'&amp;add='.$id.'">';
			
			
			// Display the admin navigation menu
			generate_admin_menu($plugin);
		
		?>

			<div class="linkst">
					<div class="inbox">
						<ul>
							<li><a href="forum.php"><?php echo $lang_common['Forum'] ?></a></li><li>&nbsp;&raquo;&nbsp;<a href="forum.php?c=<?php echo $cur_topic['cid'] ?>"><?php echo pun_htmlspecialchars($cur_topic['cat_name']) ?></a></li><li>&#160;&raquo;&#160;<?php echo pun_htmlspecialchars($cur_topic['forum_name']) ?></li>
						</ul>
					</div>
			</div>

			<div class="blockform">
				<h2><span><?php echo $action ?></span></h2>
				<div class="box">
					<?php echo $form . "\n" ?>
						<div class="inform">
							<fieldset>
								<legend><?php echo $lang_polls['Poll select'] ?></legend>
								<div class="infldset txtarea">
									<select tabindex="<?php echo $cur_index++ ?>" name="ptype">
										<option value="1"><?php echo $lang_polls['Regular'] ?></option>
										<option value="2"><?php echo $lang_polls['Multiselect'] ?></option>
										<option value="3"><?php echo $lang_polls['Yesno'] ?></option>
									</select>
								</div>
							</fieldset>
						</div>
						<p><input type="submit" name="submit" value="<?php echo $lang_common['Submit'] ?>" tabindex="<?php echo $cur_index++ ?>" accesskey="s" />&nbsp;<a href="javascript:history.go(-1)"><?php echo $lang_common['Go back'] ?></a></p>
					</form>
				</div>
			</div>
			<?php
		}
	}
	if($ptype)
	{
			// Display the admin navigation menu
			generate_admin_menu($plugin);
			
			// oblig� de copier le javascript du header car le header a d�j� �t� appel� et $required_fields n'�tait pas d�fini		
			$required_fields = array('req_question' => $lang_polls['Question']);
			$focus_element = array('req_question');
			?>
				<script type="text/javascript">
				<!--
				function process_form(the_form)
				{
					var element_names = new Object()
				<?php
				
					// Output a JavaScript array with localised field names
					while (list($elem_orig, $elem_trans) = @each($required_fields))
						echo "\t".'element_names["'.$elem_orig.'"] = "'.addslashes(str_replace('&nbsp;', ' ', $elem_trans)).'"'."\n";
				
				?>
				
					if (document.all || document.getElementById)
					{
						for (i = 0; i < the_form.length; ++i)
						{
							var elem = the_form.elements[i]
							if (elem.name && elem.name.substring(0, 4) == "req_")
							{
								if (elem.type && (elem.type=="text" || elem.type=="textarea" || elem.type=="password" || elem.type=="file") && elem.value=='')
								{
									alert("\"" + element_names[elem.name] + "\" <?php echo $lang_common['required field'] ?>")
									elem.focus()
									return false
								}
							}
						}
					}
				
					return true
				}
				// -->
				</script>
			<?php
			
			
			
			?>
			<div class="blockform">
				<h2><span>Cr�ation d'un sondage</span></h2>
				<div class="box">
					<form id="poll_ajout" method="post" action="<?php echo PLUGIN_URL.'&amp;add='.$id; ?>" onsubmit="return process_form(this)">
						<p class="submittop"><input type="submit" name="add_poll" value=" Enregistrer " tabindex="<?php echo $cur_index++ ?>" />
						<input type="hidden" name="topic_id" value="<?php echo $id; ?>" />
						<input type="hidden" name="ptype" value="<?php echo $ptype; ?>" /></p>
						<div class="inform">
							<fieldset>
							<?php			
						    // Regular Poll Type
						     if ($ptype == 1) 
							{
							?>
								<legend><?php echo $lang_polls['New poll legend'] ?></legend>
								<div class="infldset">
										<label><strong><?php echo $lang_polls['Question'] ?></strong><br /><input type="text" name="req_question" value="<?php echo pun_htmlspecialchars($question); ?>" size="80" maxlength="70" tabindex="<?php echo $cur_index++ ?>" /><br /><br /></label>
										<?php
										for ($x = 1; $x <= $pun_config['poll_max_fields'] ;$x++) 
										{
										?>
											<label><strong><?php echo $lang_polls['Option'] ?></strong><br /> <input type="text" name="poll_option[<?php echo $x; ?>]" value="<?php echo pun_htmlspecialchars($option[$x]); ?>" size="60" maxlength="55" tabindex="<?php echo $cur_index++ ?>" /><br /></label>
										<?php
										} 
										?></div></fieldset></div><?php
						    } 
							// Multiselect poll type
							elseif ($ptype == 2) 
							{
							?>
								<legend><?php echo $lang_polls['New poll legend multiselect'] ?></legend>
								<div class="infldset">
									<label><strong><?php echo $lang_polls['Question'] ?></strong><br /><input type="text" name="req_question" value="<?php echo pun_htmlspecialchars($question); ?>" size="80" maxlength="70" tabindex="<?php echo $cur_index++ ?>" /><br /><br /></label>
									<?php
									for ($x = 1; $x <= $pun_config['poll_max_fields']; $x++) 
									{
										?>
										<label><strong><?php echo $lang_polls['Option'] ?></strong><br /> <input type="text" name="poll_option[<?php echo $x; ?>]" value="<?php echo pun_htmlspecialchars($option[$x]); ?>" size="60" maxlength="55" tabindex="<?php echo $cur_index++ ?>" /><br /></label>
										<?php
									} 
									?></div></fieldset></div><?php
							} 
							elseif ($ptype == 3) 
							{
							?>
								<legend><?php echo $lang_polls['New poll legend yesno'] ?></legend>
								<div class="infldset">
									<label><strong><?php echo $lang_polls['Question'] ?></strong><br /><input type="text" name="req_question" value="<?php echo pun_htmlspecialchars($question); ?>" size="80" maxlength="70" tabindex="<?php echo $cur_index++ ?>" /><br /><br /></label>
									<label><strong><?php echo $lang_polls['Yes'] ?></strong><br /> <input type="text" name="poll_yes" value="<?php echo pun_htmlspecialchars($yesval); ?>" size="40" maxlength="35" tabindex="<?php echo $cur_index++ ?>" /></label>
									<label><strong><?php echo $lang_polls['No'] ?></strong><br /> <input type="text" name="poll_no" value="<?php echo pun_htmlspecialchars($noval); ?>" size="40" maxlength="35" tabindex="<?php echo $cur_index++ ?>" /><br /><br /></label>
									<?php
									for ($x = 1; $x <= $pun_config['poll_max_fields']; $x++) 
									{
										?>
										<label><strong><?php echo $lang_polls['Option'] ?></strong><br /> <input type="text" name="poll_option[<?php echo $x; ?>]" value="<?php echo pun_htmlspecialchars($option[$x]); ?>" size="60" maxlength="55" tabindex="<?php echo $cur_index++ ?>" /><br /></label>
										<?php
									} 
									?></div></fieldset></div><?php
							} 
							?>
							<p class="submitend"><input type="submit" name="add_poll" value=" Enregistrer " tabindex="<?php echo $cur_index++ ?>" /></p>
					</form>
				</div>
			</div>
			
	<?php
		}

}
else if (isset($_GET['del']))
{
	confirm_referrer(PLUGIN_URL);
	$id = intval($_GET['del']);
	if($id>0) // on verifie que c'est positif...
	{
		// Efface le sondage
		$db->query('DELETE FROM '.$db->prefix.'polls WHERE pollid='.$id) or error('Unable to delete poll in poll table', __FILE__, __LINE__, $db->error());
		
		$db->query('UPDATE '.$db->prefix.'topics SET question=\'\', yes=\'\', no=\'\' WHERE id='.$id) or error('Unable to delete poll in topic table', __FILE__, __LINE__, $db->error());
	}

	redirect(PLUGIN_URL, 'Sondage supprim�. Redirection ...');
}
else if (isset($_GET['raz']))
{
	confirm_referrer(PLUGIN_URL);
	$id = intval($_GET['raz']);
	if($id>0) // on verifie que c'est positif...
	{
		// Raz les votes du sondage
		$db->query('UPDATE '.$db->prefix.'polls SET voters=\'\', votes=\'\', edited='.$now.' WHERE pollid='.$id) or error('Unable to raz poll votes', __FILE__, __LINE__, $db->error());
	}

	redirect(PLUGIN_URL, 'Votes du sondage remis � z�ro. Redirection ...');
}
else	// If not, we show the "Show text" form
{
	// Display the admin navigation menu
	generate_admin_menu($plugin);

?>
	<div id="pollplugin" class="blockform">
		<h2><span>Easy Poll +</span></h2>
		<div class="box">
			<div class="inbox">
				<p>Ce plugin permet d'ajouter, �diter, supprimer des sondages.</p>
			</div>
		</div>
		
		<h2 class="block2"><span>Editer un sondage</span></h2>
		<div class="box">
			<div class="fakeform">
				<div class="inform">
					<fieldset>
						<legend>Modifier/supprimer les sondages</legend>
						<div class="infldset">
							<p>Cliquez sur le lien souhait�.<br />
							Editer permet de modifier la question et les diff�rents choix (il est possible d'en enlever ou d'en ajouter).<br />
							Supprimer permet de supprimer le sondage de la base de donn�es (seulement le sondage, pas de modifs du sujet).<br />
							R�Z permet de remettre les votes � z�ro (recommand� pour ne pas avoir de r�sultats fauss�s si vous supprimez ou 
							interchangez des options).<br />
							Pour ajouter un sondage � un sujet, �ditez le premier message de celui-ci. Un lien 'Ajouter un sondage' est pr�sent 
							si vous avez la permission de poster des sondages dans le forum correspondant.</p>
							
<?php

// Fetch poll count
if($pun_user['g_id']==PUN_ADMIN)
	$result = $db->query('SELECT COUNT(p.id) FROM '.$db->prefix.'polls AS p INNER JOIN '.$db->prefix.'topics AS t ON p.pollid=t.id INNER JOIN '.$db->prefix.'forums AS f ON t.forum_id=f.id') or error('Unable to fetch poll count', __FILE__, __LINE__, $db->error());
else
	$result = $db->query('SELECT COUNT(p.id) FROM '.$db->prefix.'polls AS p INNER JOIN '.$db->prefix.'topics AS t ON p.pollid=t.id INNER JOIN '.$db->prefix.'forums AS f ON t.forum_id=f.id WHERE f.moderators LIKE \'%;i:'.$pun_user['id'].';%\'') or error('Unable to fetch poll count', __FILE__, __LINE__, $db->error());
$num_polls = $db->result($result);

// Determine the poll offset (based on $_GET['p'])
$num_pages = ceil($num_polls / 20);

$p = (!isset($_GET['p']) || $_GET['p'] <= 1 || $_GET['p'] > $num_pages) ? 1 : $_GET['p'];
$start_from = 20 * ($p - 1);

// Generate paging links
$paging_links = paginate($num_pages, $p, PLUGIN_URL);

?>
<p class="pagelink conl"><?php echo $paging_links ?></p>
<?php
if($pun_user['g_id']==PUN_ADMIN)
	$result2 = $db->query('SELECT p.ptype, p.created, p.edited, t.id, t.subject, f.moderators FROM '.$db->prefix.'polls AS p INNER JOIN '.$db->prefix.'topics AS t ON p.pollid=t.id INNER JOIN '.$db->prefix.'forums AS f ON t.forum_id=f.id ORDER BY p.id DESC LIMIT '.$start_from.',20') or error('Unable to fetch poll list', __FILE__, __LINE__, $db->error());
else
	$result2 = $db->query('SELECT p.ptype, p.created, p.edited, t.id, t.subject, f.moderators FROM '.$db->prefix.'polls AS p INNER JOIN '.$db->prefix.'topics AS t ON p.pollid=t.id INNER JOIN '.$db->prefix.'forums AS f ON t.forum_id=f.id WHERE f.moderators LIKE \'%;i:'.$pun_user['id'].';%\' ORDER BY p.id DESC LIMIT '.$start_from.',20') or error('Unable to fetch poll list', __FILE__, __LINE__, $db->error());

$a=0;
if($db->num_rows($result2))
{
	echo '<table cellspacing="0">';
	while ($cur_poll = $db->fetch_assoc($result2))
	{
		$poll_editable=false;
		if($pun_user['group_id']!=PUN_ADMIN)
		{
			if ($cur_poll['moderators'] != '')
			{
				$mods_array = unserialize($cur_poll['moderators']);
				$moderators = array();
		
				while (list(, $mod_id) = @each($mods_array))
					$moderators[] = $mod_id;
		
				if(in_array($pun_user['id'],$moderators))
				{
					$poll_editable=true;
					$a++;
				}
			}
		}
		else
		{
			$poll_editable=true;
			$a++;
		}
		if($poll_editable)
		{
			echo "\t\t\t\t\t\t\t\t".'<tr><th scope="row"><a href="'.PLUGIN_URL.'&amp;edit='.$cur_poll['id'].'">Editer</a>';
			echo ' - <a href="'.PLUGIN_URL.'&amp;del='.$cur_poll['id'].'">Supprimer</a>';
			echo ' - <a href="'.PLUGIN_URL.'&amp;raz='.$cur_poll['id'].'">R�Z</a>';
			echo '</th><td><a href="viewtopic.php?id='.$cur_poll['id'].'">'.pun_htmlspecialchars($cur_poll['subject']).'</a></td>';
			echo '<td>';
			if($cur_poll['ptype']==1)
				echo $lang_polls['Regular'];
			else if($cur_poll['ptype']==2)
				echo $lang_polls['Multiselect'];
			else
				echo $lang_polls['Yesno'];
			echo '</td>';
			echo '<td>'.format_time($cur_poll['created']);
			if($cur_poll['edited']>0)
				echo '<br />(dernier edit : '.format_time($cur_poll['edited']).')';
			echo '</td>';
			echo '</tr>'."\n";
		}
	}
	if(!$a)
		echo '<tr><td><strong>Aucun sondage dans les forums dont vous �tes mod�rateur.</strong></td></tr>';
	?>
							</table>
	<?php
}
else
	echo '<tr><td><strong>Aucun sondage dans la base de donn�es.</strong></td></tr>';
	?>
						</div>
					</fieldset>
				</div>
			</div>
		</div>	
</div>
<?php

}

// Note that the script just ends here. The footer will be included by admin_loader.php.
