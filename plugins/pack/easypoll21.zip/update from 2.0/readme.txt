##
##        Mod title:  Easy Poll +
##
##      Mod version:  2.1
##   Works on PunBB:  1.2.17, 1.2.18
##     Release date:  05-12-08 (May, 12th)
##          Creator:  Caleb Champlin (Mediator) [med_mediator@hotmail.com]
##           Author:  BN [bnmaster@la-bnbox.info] - [http://la-bnbox.info]
##       Contribute:  Romain9441 [webmaster.rg@gmail.com] - [http://boardfun.free.fr]
##					  vin100
##					  PascL [kokoala2k3@free.fr]
##
##      Description:  Poll system for PunBB/FluxBB
##
##       Affects DB:  Yes 
##
##       DISCLAIMER:  Please note that "mods" are not officially supported by
##                    PunBB/FluxBB. Installation of this modification is done at your
##                    own risk. Backup your forum database and any and all
##                    applicable files before proceeding.
##
##   Affected files:  viewtopic.php
##		      		  post.php
##                    edit.php
##		      		  lang/LANG/polls.php
##
##
##
##			   Note:  Easy Poll + 2.0 doit �tre install� / Easy Poll + 2.0 must be installed
##

#
#---------[ 1. UPLOAD ]---------------------------------------------------
#

plugins/AMP_Sondage.php OU/OR plugins/AMP_Polls.php
lang/LANG/polls.php
update_mod.php

#
#---------[ 2. RUN ]---------------------------------------------------
#

update_mod.php

#
#---------[ 3. DELETE ]---------------------------------------------------
#

update_mod.php

#
#---------[ 4. OPEN ]---------------------------------------------------
#

edit.php

#
#---------[ 5. FIND (line: 38) ]---------------------------------------------------
#

// Fetch some info about the post, the topic and the forum
$result = $db->query('SELECT f.id AS fid, f.forum_name, f.moderators, f.redirect_url, fp.post_replies, fp.post_topics, t.id AS tid, t.subject, t.posted, t.closed, p.poster, p.poster_id, p.message, p.hide_smilies FROM '.$db->prefix.'posts AS p INNER JOIN '.$db->prefix.'topics AS t ON t.id=p.topic_id INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id='.$pun_user['g_id'].') WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND p.id='.$id) or error('Unable to fetch post info', __FILE__, __LINE__, $db->error());

#
#---------[ 6. FIND ]---------------------------------------------------
#

, fp.post_replies, fp.post_topics

#
#---------[ 7. AFTER INSERT ]---------------------------------------------------
#

, fp.post_polls, t.question

#
#---------[ 8. FIND (line: 53) ]---------------------------------------------------
#

$can_edit_subject = ($id == $topic_post_id && (($pun_user['g_edit_subjects_interval'] == '0' || (time() - $cur_post['posted']) < $pun_user['g_edit_subjects_interval']) || $is_admmod)) ? true : false;

#
#---------[ 9. ADD AFTER ]---------------------------------------------------
#

$can_add_poll = (($id == $topic_post_id) && ($cur_post['question']=='') && (($is_admmod) && (($cur_post['post_polls'] == '' && $pun_user['g_post_polls'] == '1') || $cur_post['post_polls'] == '1'))) ? true : false;

#
#---------[ 10. FIND (line: 62) ]---------------------------------------------------
#

// Load the post.php/edit.php language file
require PUN_ROOT.'lang/'.$pun_user['language'].'/post.php';

#
#---------[ 11. ADD AFTER ]---------------------------------------------------
#

require PUN_ROOT.'lang/'.$pun_user['language'].'/polls.php';


#
#---------[ 12. FIND (line: 248) ]---------------------------------------------------
#

<?php echo implode('</label>'."\n\t\t\t\t\t\t\t", $checkboxes).'</label>'."\n" ?>

#
#---------[ 13. REPLACE BY ]---------------------------------------------------
#

<?php echo implode('</label>'."\n\t\t\t\t\t\t\t", $checkboxes).'</label>'."\n";
if($can_add_poll)
	echo '<a href="admin_loader.php?plugin=AMP_Sondage.php&amp;add='.$cur_post['tid'].'">'.$lang_polls['Add poll'].'</a>'."\n";
 ?>

#
#---------[ 14. OPEN ]---------------------------------------------------
#

viewtopic.php

#
#---------[ 15. FIND ]---------------------------------------------------
#

// Fetch some info about the topic
if (!$pun_user['is_guest'])
	$result = $db->query('SELECT t.subject, t.closed, t.num_replies, t.sticky, t.question, t.yes, t.no, f.id AS forum_id, f.forum_name, f.moderators, fp.post_replies, s.user_id AS is_subscribed FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$db->prefix.'subscriptions AS s ON (t.id=s.topic_id AND s.user_id='.$pun_user['id'].') LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id='.$pun_user['g_id'].') WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.id='.$id.' AND t.moved_to IS NULL') or error('Unable to fetch topic info', __FILE__, __LINE__, $db->error());

#
#---------[ 16. FIND ]---------------------------------------------------
#

, t.num_replies, t.sticky

#
#---------[ 17. AFTER INSERT ]---------------------------------------------------
#

, t.posted

#
#---------[ 18. FIND (line: 99) ]---------------------------------------------------
#

else
	$result = $db->query('SELECT t.subject, t.closed, t.num_replies, t.sticky, t.question, t.yes, t.no, f.id AS forum_id, f.forum_name, f.moderators, fp.post_replies, 0 FROM '.$db->prefix.'topics AS t INNER JOIN '.$db->prefix.'forums AS f ON f.id=t.forum_id LEFT JOIN '.$db->prefix.'forum_perms AS fp ON (fp.forum_id=f.id AND fp.group_id='.$pun_user['g_id'].') WHERE (fp.read_forum IS NULL OR fp.read_forum=1) AND t.id='.$id.' AND t.moved_to IS NULL') or error('Unable to fetch topic info', __FILE__, __LINE__, $db->error());

#
#---------[ 19. FIND ]---------------------------------------------------
#

, t.num_replies, t.sticky

#
#---------[ 20. AFTER INSERT ]---------------------------------------------------
#

, t.posted

#
#---------[ 21. FIND ]---------------------------------------------------
#

if ($cur_topic['question'])
	$cur_topic_question = $cur_topic['question'].' - ';
else
	$cur_topic_question = '';

#
#---------[ 22. REPLACE BY ]---------------------------------------------------
#

if ($cur_topic['question'])
{
	if ($pun_config['o_censoring'] == '1')
		$cur_topic_question = censor_words($cur_topic['question']).' - ';
	else
		$cur_topic_question = $cur_topic['question'].' - ';
}
else
	$cur_topic_question = '';

#
#---------[ 23. FIND ]---------------------------------------------------
#

$result = $db->query('SELECT ptype,options,voters,votes FROM ' . $db->prefix . 'polls WHERE pollid=' . $id . '') or error('Unable to fetch poll info', __FILE__, __LINE__, $db->error());

#
#---------[ 24. REPLACE BY ]---------------------------------------------------
#

$result = $db->query('SELECT ptype,options,voters,votes,created,edited FROM ' . $db->prefix . 'polls WHERE pollid=' . $id . '') or error('Unable to fetch poll info', __FILE__, __LINE__, $db->error());

#
#---------[ 25. FIND ]---------------------------------------------------
#

<p class="poll_info">Total : <?php echo $total; ?></p>
			<?php
		} 
		?>
			</div>

#
#---------[ 26. ADD AFTER ]---------------------------------------------------
#

<?php
if($cur_topic['posted']!=$cur_poll['created'])
{
	echo "\t\t\t\t\t".'<p class="postedit"><em>'.$lang_polls['Poll Creation'].' : '.format_time($cur_poll['created']);
	if ($cur_poll['edited'] != 0)
		echo '<br />'.$lang_polls['Poll Edition'].' ('.format_time($cur_poll['edited']).')';
	echo '</em></p>'."\n";
}
else
	if ($cur_poll['edited'] != 0)
		echo "\t\t\t\t\t".'<p class="postedit"><em>'.$lang_polls['Poll Edition'].' ('.format_time($cur_poll['edited']).')</em></p>'."\n";
?>

#
#---------[ 27. OPEN ]---------------------------------------------------
#

post.php

#
#---------[ 28. FIND ]---------------------------------------------------
#

while (list($key, $value) = each($_POST['poll_option'])) 
{
	$value = pun_trim($value);
    if ($value != "")
	{
        if ($lastoption == '')
            $errors[] = $lang_polls['Empty option'];
        else
		{
            $option[$key] = pun_trim($value);
            if (pun_strlen($option[$key]) > 55)
                $errors[] = $lang_polls['Too long option'];
			else if ($key > $pun_config['poll_max_fields'])
				message($lang_common['Bad request']);
            else if ($pun_config['p_subject_all_caps'] == '0' && strtoupper($option[$key]) == $option[$key] && ($pun_user['g_id'] > PUN_MOD && !$pun_user['g_global_moderation']))
                $option[$key] = ucwords(strtolower($option[$key]));
        }
    }
    $lastoption = pun_trim($value);
}

#
#---------[ 29. REPLACE BY ]---------------------------------------------------
#

while (list($key, $value) = each($_POST['poll_option'])) 
{
	$value = pun_trim($value);
    if ($value != "") 
	{
        if ($lastoption == '')
            $errors[] = $lang_polls['Empty option'];
        
        $option[$key] = pun_trim($value);
        if (pun_strlen($option[$key]) > 55)
            $errors[] = $lang_polls['Too long option'];
		else if ($key > $pun_config['poll_max_fields'])
			message($lang_common['Bad request']);
        else if ($pun_config['p_subject_all_caps'] == '0' && strtoupper($option[$key]) == $option[$key] && ($pun_user['g_id'] > PUN_MOD && !$pun_user['g_global_moderation']))
            $option[$key] = ucwords(strtolower($option[$key]));
    }
    $lastoption = pun_trim($value);
}

#
#---------[ 30. FIND ]---------------------------------------------------
#

if ($ptype != 0) 
	$db->query('INSERT INTO ' . $db->prefix . 'polls (pollid, options, ptype) VALUES(' . $new_tid . ', \'' . $db->escape(serialize($option)) . '\', ' . $ptype . ')') or error('Unable to create poll', __FILE__, __LINE__, $db->error());

#
#---------[ 31. REPLACE BY ]---------------------------------------------------
#

if ($ptype != 0) 
	$db->query('INSERT INTO ' . $db->prefix . 'polls (pollid, options, ptype, created) VALUES(' . $new_tid . ', \'' . $db->escape(serialize($option)) . '\', ' . $ptype . ', '.$now.')') or error('Unable to create poll', __FILE__, __LINE__, $db->error());

#
#---------[ 32. SAVE, UPLOAD ]---------------------------------------------------
#

edit.php
viewtopic.php
post.php