<?php
/***********************************************************************/

// Some info about your mod.
$mod_title      = 'Easy Poll +';
$mod_version    = '2.1';
$release_date   = '05-12-08';
$creator         = 'Caleb Champlin (Mediator)';
$creator_email   = 'med_mediator@hotmail.com';
$author         = 'BN';
$author_email   = 'bnmaster@la-bnbox.info';
$contribute         = 'Romain9441, vin100, PascL';

// One or more versions of PunBB/FluxBB that this mod works on. The version names must match exactly!
$punbb_versions	= array('1.2.17', '1.2.18');

// Set this to false if you haven't implemented the restore function (see below)
$mod_restore	= true;


// This following function will be called when the user presses the "Install" button.
function install()
{
	global $db, $db_type, $pun_config;
	$db->query("ALTER TABLE ".$db->prefix."topics ADD `question` VARCHAR(255) NOT NULL, ADD `yes` VARCHAR(30) NOT NULL, ADD `no` VARCHAR(30) NOT NULL") or error('Impossible d\'ajouter les champs n�cessaires � la table', __FILE__, __LINE__, $db->error());
	$db->query("ALTER TABLE ".$db->prefix."groups ADD `g_post_polls` TINYINT(1) DEFAULT '1' NOT NULL") or error('Impossible d\'ajouter les champs n�cessaires � la table', __FILE__, __LINE__, $db->error());
	$db->query("ALTER TABLE ".$db->prefix."forum_perms ADD `post_polls` TINYINT(1) DEFAULT '1' NOT NULL") or error('Impossible d\'ajouter les champs n�cessaires � la table', __FILE__, __LINE__, $db->error());
	
	switch ($db_type)
	{
		case 'mysql':
		case 'mysqli':
			$sql = 'CREATE TABLE '.$db->prefix."polls (
					id INT(11) NOT NULL AUTO_INCREMENT,
					pollid INT(11) NOT NULL default '0',
					options LONGTEXT NOT NULL,
					voters LONGTEXT NOT NULL,
					ptype tinyint(4) NOT NULL default '0',
					votes LONGTEXT NOT NULL,
					created INT(10) UNSIGNED NOT NULL DEFAULT 0,
					edited INT(10) UNSIGNED NOT NULL DEFAULT 0,
					PRIMARY KEY (id)
					) TYPE=MyISAM;";
			break;

		case 'pgsql':
			$sql = 'CREATE TABLE '.$db->prefix."polls (
					id SERIAL,
					pollid INTEGER NOT NULL default 0,
					options TEXT NOT NULL,
					voters TEXT NOT NULL,
					ptype SMALLINT NOT NULL default 0,
					votes TEXT NOT NULL,
					created INTEGER UNSIGNED NOT NULL DEFAULT 0,
					edited INTEGER UNSIGNED NOT NULL DEFAULT 0,
					PRIMARY KEY (id)
					)";
			break;

		case 'sqlite':
			$sql = 'CREATE TABLE '.$db->prefix."polls (
					id INTEGER NOT NULL,
					pollid INTEGER NOT NULL default 0,
					options TEXT NOT NULL,
					voters TEXT NOT NULL,
					ptype INTEGER NOT NULL default 0,
					votes TEXT NOT NULL,
					created INTEGER UNSIGNED NOT NULL DEFAULT 0,
					edited INTEGER UNSIGNED NOT NULL DEFAULT 0,
					PRIMARY KEY (id)
					)";
			break;
	}
	$db->query($sql) or error('Impossible de cr�er la table '.$db->prefix.'polls.',  __FILE__, __LINE__, $db->error());
	
	
	$db->query('INSERT INTO '.$db->prefix."config (conf_name, conf_value) VALUES('poll_max_fields', '10')")	or error('Impossible de r�aliser l\'insertion dans la table '.$db->prefix.'config. V�rifier votre installation et r�essayer. <a href="JavaScript: history.go(-1)">Retour</a>.', __FILE__, __LINE__, $db->error());


	$d = dir(PUN_ROOT.'cache');
	while (($entry = $d->read()) !== false)
	{
		if (substr($entry, strlen($entry)-4) == '.php')
			@unlink(PUN_ROOT.'cache/'.$entry);
	}


	$db->close();
}

/***********************************************************************\
 The restore function 
\***********************************************************************/

function restore()
{
	global $lang, $db, $db_type;
	
	$errors = array();
	
	if (!$db->query('DELETE FROM '.$db->prefix.'config WHERE conf_name = \'poll_max_fields\' LIMIT 1;'))
		$errors[] = sprintf($lang['err_5'], $db->prefix.'config =&gt; poll_max_fields');
		
	if (!$db->query('ALTER TABLE '.$db->prefix.'groups DROP g_post_polls ;'))
		$errors[] = sprintf($lang['err_5'], $db->prefix.'groups =&gt; g_post_polls');
	
	if (!$db->query('ALTER TABLE '.$db->prefix.'topics DROP question, DROP yes, DROP no ;'))
		$errors[] = sprintf($lang['err_5'], $db->prefix.'topics =&gt; question / '.$db->prefix.'topics =&gt; yes / '.$db->prefix.'topics =&gt; no');
	
	if (!$db->query('DROP TABLE '.$db->prefix.'polls ;'))
		$errors[] = sprintf($lang['err_5'], $db->prefix.'polls');
	
	// delete everything in the cache since we messed with some stuff
	$d = dir(PUN_ROOT.'cache');
	while (($entry = $d->read()) !== false)
	{
		if (substr($entry, strlen($entry)-4) == '.php')
			@unlink(PUN_ROOT.'cache/'.$entry);
	}
	$d->close();	
	
	if (!empty($errors))
		error('<ul><li>'.implode('</li><li>',$errors).'</li></ul>', '', '');
}

/***********************************************************************\
 Languages definitions
\***********************************************************************/

$english_array = array(
'err_1' => 'Unable to access to the configuration',
'err_2' => 'Unable to create table %s',
'err_3' => 'Unable to insert in table %s',
'err_4' => 'Unable to add column to the table %s',
'err_5' => 'Unable to delete %s ; please remove manually',
'err_6' => 'You are running a version of PunBB/FluxBB (%s) that this mod does not support. This mod supports PunBB/FluxBB versions: %s',

'install_mod_x' => '%s installation',
'install_mod' => 'Mod installation',

'mod_title' => 'Mod title:',
'mod_author' => 'Author:',
'mod_creator' => 'Creator:',
'mod_contribute' => 'Contribute:',
'disclaimer' => 'Disclaimer:',

'install_mod_p1' => 'This script will update your database to work with the following modification:',
'install_mod_p2' => 'Mods are not officially supported by PunBB/FluxBB. Mods generally can\'t be uninstalled without running SQL queries manually against the database. Make backups of all data you deem necessary before installing.',
'install_mod_p3' => 'If you\'ve previously installed this mod and would like to uninstall it, you can click the restore button below to restore the database.',

'install' => 'Install',
'restore' => 'Restore',

'install_success' => 'Installation successful',
'install_success_info' => 'Your database has been successfully prepared for %s. See readme.txt for further instructions.',

'restore_success' => 'Restore successful',
'restore_success_info' => 'Your database has been successfully restored.',

);

$french_array = array(
'err_1' => 'Impossible d\'acc�der � la configuration',
'err_2' => 'Impossible de cr�er la table %s',
'err_3' => 'Impossible d\'ins�rer dans la table %s',
'err_4' => 'Impossible d\'ajouter des colonnes � la table %s',
'err_5' => 'Impossible de supprimer %s ; veuillez supprimer manuellement.',
'err_6' => 'Vous utilisez une version de PunBB/FluxBB (%s) que cette mod ne prend pas en charge. Cette mod supporte les versions %s de PunBB/FluxBB',

'install_mod_x' => 'Installation %s',
'install_mod' => 'Installation mod',

'mod_title' => 'Titre mod&nbsp;:',
'mod_author' => 'Auteur&nbsp;:',
'mod_creator' => 'Cr�ateur&nbsp;:',
'mod_contribute' => 'Contributeur&nbsp;:',
'disclaimer' => 'Disclaimer&nbsp;:',

'install_mod_p1' => 'Ce script va mettre � jour votre base de donn�es afin qu\'elle puisse fonctionner avec la modification suivante&nbsp;:',
'install_mod_p2' => 'Veuillez noter que les mods ne sont pas officiellement support�es par PunBB/FluxBB. Vous ne pouvez g�n�ralement pas d�sinstaller compl�tement les mods sans lancer manuellement des requ�tes � la base de donn�es. N\'oubliez pas de sauvegarder la base de donn�es et les fichiers affect�s avant de proc�der � l\'installation. Vous �tes le seul et unique responsable des �ventuels domages que pourrait engendrer l\'installation de la mod. Vous effectuez cette modification � vos risques et p�rils.',
'install_mod_p3' => 'Si vous avez pr�c�demment install� cette mod et voulez la d�sinstaller, vous pouvez cliquer sur le bouton de restauration ci-dessous afin de restaurer la base de donn�es.',

'install' => 'Installation',
'restore' => 'Restauration',

'install_success' => 'Installation r�ussie',
'install_success_info' => 'Votre base de donn�e a �t� correctement pr�par� pour %s. Veuillez consulter le lisez_moi.txt pour les instructions compl�mentaires.',

'restore_success' => 'Restauration r�ussie',
'restore_success_info' => 'Votre base de donn�es � �t� correctement restaur�e.',

);


/***********************************************************************\
 Running and displaying 
\***********************************************************************/

// Circumvent maintenance mode
define('PUN_TURN_OFF_MAINT', 1);
define('PUN_ROOT', './');
require PUN_ROOT.'include/common.php';

// We want the complete error message if the script fails
if (!defined('PUN_DEBUG'))
	define('PUN_DEBUG', 1);

// Set language
if ($pun_config['o_default_lang'] == 'English')
	$lang = $english_array;
elseif ($pun_config['o_default_lang'] == 'French')
	$lang = $french_array;
else
	$lang = $english_array;

// Make sure we are running a PunBB/FluxBB version that this mod works with
$version = explode(".", $pun_config['o_cur_version']);
if ($version[0] != 1 || $version[1] != 2)
{
	$err_str = sprintf($lang['err_6'],$pun_config['o_cur_version'], '1.2.x');
	exit($err_str);
}
$style = (isset($cur_user)) ? $cur_user['style'] : $pun_config['o_default_style'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php printf($lang['install_mod_x'], $mod_title); ?></title>
<link rel="stylesheet" type="text/css" href="style/<?php echo $pun_config['o_default_style'].'.css' ?>" />
</head>
<body>

<div id="punwrap">
<div id="puninstall" class="pun" style="margin: 10% 20% auto 20%">

<?php

if (isset($_POST['form_sent']))
{
	if (isset($_POST['install']))
	{
		// Run the install function (defined above)
		install();
?>
<div class="block">
	<h2><span><?php echo $lang['install_success']; ?></span></h2>
	<div class="box">
		<div class="inbox">
			<p><?php printf($lang['install_success_info'],pun_htmlspecialchars($mod_title) ); ?></p>
		</div>
	</div>
</div>
<?php

	}
	else {
		// Run the restore function (defined above)
		restore();
?>
<div class="block">
	<h2><span><?php echo $lang['restore_success']; ?></span></h2>
	<div class="box">
		<div class="inbox">
			<p><?php echo $lang['restore_success_info']; ?></p>
		</div>
	</div>
</div>
<?php

	}
}
else
{

?>
<div class="blockform">
	<h2><span><?php echo $lang['install_mod']; ?></span></h2>
	<div class="box">
		<form method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?foo=bar">
			<div><input type="hidden" name="form_sent" value="1" /></div>
			<div class="inform">
				<p><?php echo $lang['install_mod_p1'] ?></p>
				<p><strong><?php echo $lang['mod_title'] ?></strong> <?php echo pun_htmlspecialchars($mod_title).' '.$mod_version ?></p>
				<p><strong><?php echo $lang['mod_creator'] ?></strong> <?php echo pun_htmlspecialchars($creator) ?> (<a href="mailto:<?php echo pun_htmlspecialchars($creator_email) ?>"><?php echo pun_htmlspecialchars($creator_email) ?></a>)</p>
				<p><strong><?php echo $lang['mod_author'] ?></strong> <?php echo pun_htmlspecialchars($author) ?> (<a href="mailto:<?php echo pun_htmlspecialchars($author_email) ?>"><?php echo pun_htmlspecialchars($author_email) ?></a>)</p>
				<p><strong><?php echo $lang['mod_contribute'] ?></strong> <?php echo pun_htmlspecialchars($contribute) ?></p>
				<p><strong><?php echo $lang['disclaimer'] ?></strong> <?php echo $lang['install_mod_p2'] ?></p>
<?php if ($mod_restore): ?><p><?php echo $lang['install_mod_p3'] ?></p>
<?php endif; ?></div>
			<p><input type="submit" name="install" value="<?php echo $lang['install'] ?>" /><?php if ($mod_restore): ?><input type="submit" name="restore" value="<?php echo $lang['restore'] ?>" /><?php endif; ?></p>
		</form>
	</div>
</div>
<?php

}

?>

</div>
</div>

</body>
</html>
